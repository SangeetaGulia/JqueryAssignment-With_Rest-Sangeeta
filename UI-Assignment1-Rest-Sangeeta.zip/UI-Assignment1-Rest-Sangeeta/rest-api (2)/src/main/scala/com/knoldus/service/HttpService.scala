package com.knoldus.service

import java.sql.{Statement, DriverManager, Connection}

import org.slf4j.LoggerFactory

import akka.actor.ActorSystem
import akka.http.scaladsl.Http

import akka.stream.ActorMaterializer
import com.knoldus.repo.repo.{StudentRepository, Student}

import scala.collection.mutable.ListBuffer

//import scala.concurrent.ExecutionContext.Implicits.global


object HttpService extends App with Routes with FakeRepo {

  implicit val system = ActorSystem()
  implicit val materializer = ActorMaterializer()

  Http().bindAndHandle(route, "localhost", 9000)



}

trait FakeRepo extends StudentRepository {

  def getConnection():Connection= {
    val url: String = "jdbc:mysql://localhost/Student"
    Class.forName("com.mysql.jdbc.Driver")
    try {
      val conn: Connection = DriverManager.getConnection(url, "root", "knoldus")
      conn
    }
    catch {
      case ex: Exception =>
        val logger = LoggerFactory.getLogger(this.getClass())
        logger.info("Attempt to create connection Failed" + ex)
        null
    }

  }
  def create(student:Student):Student={

    try {
      val conn = getConnection()
      val stat: Statement = conn.createStatement()
      val rs: Int = stat.executeUpdate("insert into student values(" + student.id + ",'" + student.name + "','"  + student.email + "');")
      conn.close()
      Student(student.id, student.name, student.email)
    }
    catch{
      case ex:Exception =>
        val logger = LoggerFactory.getLogger(this.getClass())
        logger.info("Exception while inserting : " + ex)
        Student(0,"","")
    }
  }

  def getById(id:Int):Student={

    try {
      val con = getConnection()

      val statement = con.createStatement()
      val res = statement.executeQuery("Select * from student where id="
        + id + ";")
      if (res.next()) {
        val id = res.getInt("student.id")
        val name = res.getString("student.name")
        val email = res.getString("student.email")
        Student(id, name, email)

      }
      else
        Student(0, "", "")

    }
    catch{
      case ex:Exception =>
        val logger = LoggerFactory.getLogger(this.getClass())
        logger.info("Exception while retrieving : " + ex)
        Student(0,"","")
    }

  }

  def getAll():List[Student]={
    val con = getConnection()
    val listOfStudent:ListBuffer[Student]=ListBuffer()
    val statement = con.createStatement()
    val res = statement.executeQuery("Select * from student ;")
    while(res.next()) {
      val id = res.getInt("student.id")
      val name = res.getString("student.name")
      val email = res.getString("student.email")
      listOfStudent+=Student(id, name, email)
    }

    listOfStudent.toList

  }

}


/*class Repository extends FakeRepo{

  def getConnection():Connection={
    val url:String = "jdbc:mysql://localhost/Student"
    Class.forName("com.mysql.jdbc.Driver")
    try {
      val conn: Connection = DriverManager.getConnection(url, "root", "knoldus")
      conn
    }
    catch{
      case ex:Exception =>
        val logger = LoggerFactory.getLogger(this.getClass())
        logger.info("Attempt to create connection Failed" + ex)
        null
    }

  }


  override def create(student:Student):Student={
    try {
      val conn = getConnection()
      val stat: Statement = conn.createStatement()
      val rs: Int = stat.executeUpdate("insert into student values(" + student.id + ",'" + student.name + "','"  + student.email + "');")
      conn.close()
      Student(student.id, student.name, student.email)
    }
    catch{
      case ex:Exception =>
        val logger = LoggerFactory.getLogger(this.getClass())
        logger.info("Exception while inserting : " + ex)
        Student(0,"","")
    }
  }

  override def getById(id:Int):Student ={

    try {
      val con = getConnection()

      val statement = con.createStatement()
      val res = statement.executeQuery("Select * from student where id="
        + id + ";")
      if (res.next()) {
        val id = res.getInt("student.id")
        val name = res.getString("student.name")
        val email = res.getString("student.email")
        Student(id, name, email)

      }
      else
        Student(0, "", "")

    }
    catch{
      case ex:Exception =>
        val logger = LoggerFactory.getLogger(this.getClass())
        logger.info("Exception while retrieving : " + ex)
        Student(0,"","")
    }

  }

  override def getAll():List[Student]={
    val con = getConnection()
    val l:ListBuffer[Student]=ListBuffer()
    val statement = con.createStatement()
    val res = statement.executeQuery("Select * from student ;")
    while(res.next()) {
      val id = res.getInt("student.id")
      val name = res.getString("student.name")
      val email = res.getString("student.email")
      l+=Student(id, name, email)
    }

    l.toList
  }
}
*/