package com.knoldus.service

import com.knoldus.repo.repo.Student
import org.scalatest.FunSuite
/**
  * Created by knodus on 28/2/16.
  */
class HttpServiceTest extends FunSuite{

  val stud=Student(2,"Antra","abc@xyz.com")
  val fakerep=new Repository
  test("StudentImpl : insertRecord :Adding new row"){

    val result=fakerep.create(stud)
    assert(result===Student(2,"Antra","abc@xyz.com"))
  }


}
